
export const $contextColor = 'rgba(110,136,255,0.8)'
export const $contextColorLight = 'rgba(130, 153, 255, 0.8)'
export const $contextColorDark = 'rgba(69, 103, 255, 0.8)'
export const $contextMenuRound = '5px'
export const $width = 120
