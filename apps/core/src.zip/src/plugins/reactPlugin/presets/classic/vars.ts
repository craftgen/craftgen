export const $nodecolor = 'rgba(110,136,255,0.8)'
export const $nodecolorselected = '#ffd92c'
export const $socketsize = 24
export const $socketmargin = 6
export const $socketcolor = '#96b38a'
export const $nodewidth = 180
