export function px(value: number) {
  return `${value}px`
}
