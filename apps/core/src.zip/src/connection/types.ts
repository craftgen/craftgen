import { ClassicPreset } from "rete";

export type Node = ClassicPreset.Node & { width: number; height: number };
